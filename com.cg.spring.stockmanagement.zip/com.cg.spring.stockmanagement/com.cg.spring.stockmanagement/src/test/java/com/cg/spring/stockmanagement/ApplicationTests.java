package com.cg.spring.stockmanagement;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import com.cg.spring.stockmanagement.controller.ManagerController;
import com.cg.spring.stockmanagement.model.Company;
import com.cg.spring.stockmanagement.model.Manager;
import com.cg.spring.stockmanagement.exceptions.InvalidOperation;
import com.cg.spring.stockmanagement.service.ManagerService;

@ExtendWith(MockitoExtension.class)
public class ApplicationTests{
    
	

	@Mock
	ManagerService managerServices;
	

	@InjectMocks
	ManagerController managerController;

	@Test
	public void testaddManagerInfo()
	{
		Company company = new Company("capgemini",45,1000);
		Manager manager =new Manager("Jenny","jenny@gmail.com","1234",company);
		
		 Mockito.when(managerController.addManagerInfo(manager)).thenReturn(manager);
         assertEquals(manager,managerController.addManagerInfo(manager));
	 }
	
	 @Test
	  public void testGetAllManagerInfo()
	 {
	        List<Manager> manager=new ArrayList<Manager>();
	       Mockito.when(managerController.getAllManagerInfo()).thenReturn(manager);
	        assertEquals(manager,managerController.getAllManagerInfo());

	  }
	 
	
	 
	 @Test
	 public void testgetManagerDetails() throws InvalidOperation {
		 Company company = new Company("Honda",47,2000);
		 Manager manager1=new Manager("Meesha","meesha@gmail.com","24567",company);
		 int id=60;
		 Mockito.when(managerController.getManagerDetails(60)).thenReturn(manager1);
	        assertEquals(manager1,managerController.getManagerDetails(60));
	 }
	 
	 @Test
	 public void testupdateManagerInfo()throws InvalidOperation
	 {
		 Company company = new Company("Sony",47,2000);
			Manager manager=new Manager("Mike","mike@gmail.com","4567",company);
			
			Mockito.when(managerController.updateManagerInfo(manager)).thenReturn(manager);
		    assertEquals(manager,managerController.updateManagerInfo( manager));
	 }
	 

	 @Test
	 public void testdeleteManagerInfo() throws InvalidOperation
	 {
		 Company company = new Company("Birla",50,4000);
			Manager manager=new Manager("Sara","sara@gmail.com","4567",company);
	 	
	 	int id=48;
		Mockito.when(managerController.deleteManagerInfo(48)).thenReturn(manager);
	 	assertEquals(manager,managerController.deleteManagerInfo(48));
	 	
	 }
}