package com.cg.spring.stockmanagement.controller;


import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.spring.stockmanagement.model.Manager;
import com.cg.spring.stockmanagement.exceptions.InvalidOperation;
import com.cg.spring.stockmanagement.model.Company;

public interface IManagerController
{
	
	//------------------------ 1. StockExchanageManagement Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addManagerInfo(Manager info) 
	 - Input Parameters	:	Manager info
	 - Return Type		:	Manager
	 - Author			:	Jenny Thanushaw
	 - Creation Date	:	10/11/2020
	 - Description		:	Adding Manager into the database
	 ********************************************************************************************************/
	public @ResponseBody Manager addManagerInfo(@RequestBody Manager info);
	
	//------------------------ 1. StockExchangeManagement Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getAllManagerInfo() 
	 - Input Parameters	:	No
	 - Return Type		:	List<Manager>
	 - Author			:	JennyThanushaw
	 - Creation Date	:	10/11/2020
	 - Description		:	Getting all the Managers present in the database
	 ********************************************************************************************************/
	
	public @ResponseBody List<Manager> getAllManagerInfo();
	
	//------------------------ 1. StockExchangeManagement Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getManagerDetails(Integer managerId);
	 - Input Parameters	:	Integer managerId
	 - Return Type		:	manager
	 - Author			:	JennyThanushaw
	 - Creation Date	:	10/11/2020
	 - Description		:	getting Manager details from the database
	 ********************************************************************************************************/
	
	public @ResponseBody Manager getManagerDetails(@PathVariable int managerId);
	
	//------------------------ 1. StockExchangeManagement Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	updateManagerInfo(Manager info) 
		 - Input Parameters	:	Manager info
		 - Return Type		:	manager
		 - Author			:	JennyThanushaw
		 - Creation Date	:	10/11/2020
		 - Description		:	updating the Manager details
		 ********************************************************************************************************/
	
	public @ResponseBody Manager updateManagerInfo(@RequestBody Manager info);
	
	//------------------------ 1. StockExchangeManagement Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	deleteManagerInfo(Manager info) 
			 - Input Parameters	:	Manager info
			 - Return Type		:	manager
			 - Author			:	JennyThanushaw
			 - Creation Date	:	10/11/2020
			 - Description		:	deleting the Manager details
			 ********************************************************************************************************/
		
	
	public @ResponseBody Manager deleteManagerInfo(@PathVariable int managerId);
	
	
		
	
	



}
