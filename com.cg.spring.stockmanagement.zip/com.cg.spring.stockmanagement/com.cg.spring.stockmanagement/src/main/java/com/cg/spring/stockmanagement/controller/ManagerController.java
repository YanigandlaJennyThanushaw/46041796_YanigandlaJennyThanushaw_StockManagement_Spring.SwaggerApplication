package com.cg.spring.stockmanagement.controller;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.stockmanagement.model.Manager;
import com.cg.spring.stockmanagement.service.ManagerService;

//connect from postman as http://localhost:8086/swagger-ui.html

@Controller
@RequestMapping("/Manager")
public class ManagerController {
	//Logger logger=LoggerFactory.getLogger(ManagerController.class);
	@Autowired
	ManagerService managerService;

	//Creating a post mapping that post the Manager detail into the database
	
	@PostMapping("/")
	public @ResponseBody Manager addManagerInfo(@RequestBody Manager info) 
	{
		//logger.info("manager service was instalized");
		return managerService.addManagerInfo(info);
	}
	
	//Creating a get mapping that retrives the all Manager info from the database
	
	@GetMapping("/")
	public @ResponseBody List<Manager> getAllManagerInfo() 
	{ 
		
		 return managerService.getAllManagerInfo();
	}
	
	//Creating a get mapping that retrives the detail of a specific Manager info
	
	@GetMapping("/{managerId}")
	public @ResponseBody Manager getManagerDetails(@PathVariable int managerId)
	{
		return  managerService.getManagerDetails(managerId);
	}
	
	//Creating put mapping that updates the Manager info
	
	@PutMapping("/")
	public @ResponseBody Manager updateManagerInfo(@RequestBody Manager info)
	{
		return managerService.updateManagerInfo(info);
	}
	
	//Create delete mapping that deletes a specific Manager
	
	@DeleteMapping("/{managerId}")
	public @ResponseBody Manager deleteManagerInfo(@PathVariable int managerId) 
	{
		return managerService.deleteManagerInfo(managerId);
	}
	

	
	
}

	
	
	