package com.cg.spring.stockmanagement.dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.spring.stockmanagement.model.Company;
import com.cg.spring.stockmanagement.model.Manager;

@Repository
public interface Managerdao extends JpaRepository<Manager, Integer>{


	

}



