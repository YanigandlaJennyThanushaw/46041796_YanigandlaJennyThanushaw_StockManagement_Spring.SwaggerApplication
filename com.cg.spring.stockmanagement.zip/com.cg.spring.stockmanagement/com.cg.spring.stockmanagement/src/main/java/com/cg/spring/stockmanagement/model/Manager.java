package com.cg.spring.stockmanagement.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.persistence.CascadeType;
import javax.persistence.Column;
//Mark class as an Entity
@Entity
//defining class name as Table name
@Table(name="manager_info")
public class Manager 
{
	//Defining manager id as primary key
	@Id
	@GeneratedValue
	private int managerId;
	
	private String managerName;

	private String email;
	private String mobileNo;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="company_id")
	
	private Company company;
	
	
	
    
	public Manager(String managerName, String email, String mobileNo,Company Company) {
		super();
		this.managerName = managerName;
		this.email = email;
		this.mobileNo = mobileNo;
		this.company = company;
		
	}
	public Manager() {
	}
	public Manager(int managerId, String managerName, String email, String mobileNo, Company company) {
		super();
		this.managerId = managerId;
		this.managerName = managerName;
		this.email = email;
		this.mobileNo = mobileNo;
		this.company = company;
	}

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	@Override
	public String toString() {
		return "Manager [managerId=" + managerId + ", managerName=" + managerName + ", email=" + email + ", mobileNo="
				+ mobileNo + ", company=" + company + "]";
	}

	
	}

