package com.cg.spring.stockmanagement.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.stockmanagement.dao.Managerdao;
import com.cg.spring.stockmanagement.model.Company;
import com.cg.spring.stockmanagement.model.Manager;
import com.cg.spring.stockmanagement.validations.Validations;

import com.cg.spring.stockmanagement.exceptions.InvalidOperation;


@Service
public class ManagerService  {
	@Autowired
	Managerdao managerdao;

	
	
		
		
		public Manager addManagerInfo(Manager info)
		{
			try
			{
				if( (Validations.name(info.getManagerName())) && 
				   (Validations.email(info.getEmail())) && (Validations.mobileNo(info.getMobileNo())))
				  
					return managerdao.save(info);
				else
					throw new InvalidOperation("Manager details are not valid");
			}
			catch(InvalidOperation e) 
			{
				System.out.println(e);
			}
			return null;
		}
		
	
		public List<Manager> getAllManagerInfo() 
		{
			return managerdao.findAll();
		}
		
		public Manager getManagerDetails(int managerId)
		{
			Optional<Manager> manager=managerdao.findById(managerId);
			try
			{
				if(manager.isPresent())
					return manager.get();
				else
					throw new InvalidOperation("No Manager found with given id");
			}
			catch(InvalidOperation e)
			{
				System.out.println(e);
			}
			return null;
		}

		public Manager updateManagerInfo(Manager info) 
		{
			try
			{
				if( (Validations.name(info.getManagerName())) && 
				   (Validations.email(info.getEmail())) && (Validations.mobileNo(info.getMobileNo())))
				   
					return managerdao.save(info);
				else
					throw new InvalidOperation("Manager details are not valid");
			}
			catch(InvalidOperation e)
			{
				System.out.println(e);
			}
			return null;
		}

		public Manager deleteManagerInfo(int managerId) 
		{
			Optional<Manager> manager=managerdao.findById(managerId);
			try
			{
				if(manager.isPresent())
				{
					managerdao.deleteById(managerId);
					return manager.get();
				}
				else
					throw new InvalidOperation("No Manager found with given id");
			}
			catch(InvalidOperation e)
			{
				System.out.println(e);
			}
			return null;
		}
	
		
		
	}

