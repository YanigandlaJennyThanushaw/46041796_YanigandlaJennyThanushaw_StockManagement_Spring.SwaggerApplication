package com.cg.spring.stockmanagement.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

//Mark class as an Entity
@Entity
//Defining class an Table name
@Table(name="company_info")
public class Company 
{
	//Defining company id as primary key
	@Id
	@GeneratedValue
	private int companyId;
	
	
	private String companyName;
	
	private int noOfStocks;
	
	private double stockPrice;
		
	
	public Company() {
		
	}

	public Company(String companyName, int noOfStocks, double stockPrice) {
		super();
		this.companyName = companyName;
		this.noOfStocks = noOfStocks;
		this.stockPrice = stockPrice;
		}
	public Company(int companyId, String companyName,  int noOfStocks, double stockPrice) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		
		this.noOfStocks = noOfStocks;
		this.stockPrice = stockPrice;
	}


	public int getCompanyId() {
		return companyId;
	}


	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	


	public int getNoOfStocks() {
		return noOfStocks;
	}


	public void setNoOfStocks(int noOfStocks) {
		this.noOfStocks = noOfStocks;
	}


	public double getStockPrice() {
		return stockPrice;
	}


	public void setStockPrice(double stockPrice) {
		this.stockPrice = stockPrice;
	}


	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", noOfStocks=" + noOfStocks
				+ ", stockPrice=" + stockPrice + "]";
	}
	
}
