package com.cg.spring.stockmanagement.service;



import java.util.List;
import com.cg.spring.stockmanagement.exceptions.InvalidOperation;
import com.cg.spring.stockmanagement.model.Company;
import com.cg.spring.stockmanagement.model.Manager;

public interface IManagerService 
{
	//------------------------ 1. StockExchanageManagement Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	addManagerInfo(Manager info) 
		 - Input Parameters	:	Manager info
		 - Return Type		:	Manager
		 - Author			:	Jenny Thanushaw
		 - Creation Date	:	10/11/2020
		 - Description		:	Adding Manager details to database calls Controller method addManagerInfo(Manager info)

		 ********************************************************************************************************/
	
	public Manager addManagerInfo(Manager info);
	

	//------------------------ 1. StockExchangeManagement Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getAllManagerInfo() 
	 - Input Parameters	:	No
	 - Return Type		:	List<Manager>
	 - Author			:	JennyThanushaw
	 - Creation Date	:	10/11/2020
	 - Description		:   Getting Manager details in database calls Controller method getAllManagerInfo()

	 ********************************************************************************************************/
	
	public List<Manager> getAllManagerInfo();
	
	//------------------------ 1. StockExchangeManagement Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	getManagerDetails(Integer managerId);
		 - Input Parameters	:	Integer managerId
		 - Return Type		:	manager
		 - Author			:	JennyThanushaw
		 - Creation Date	:	10/11/2020
		 - Description		:	Getting Manager details from database calls Controller method getManagerDetails(Integer ManagerId)

		 ********************************************************************************************************/
	public Manager getManagerDetails(int managerId);
	
	//------------------------ 1. StockExchangeManagement Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	updateManagerInfo(Manager info) 
			 - Input Parameters	:	Manager info
			 - Return Type		:	manager
			 - Author			:	JennyThanushaw
			 - Creation Date	:	10/11/2020
			 - Description		:	updating Manager details to database calls Controller method UpdateManagerInfo(Manager info)

			 ********************************************************************************************************/
		
	public Manager updateManagerInfo(Manager info) ;
	
	//------------------------ 1. StockExchangeManagement Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getManager(Company company) 
	 - Input Parameters	:	Company company
	 - Return Type		:	manager
	 - Author			:	JennyThanushaw
	 - Creation Date	:	10/11/2020
	 - Description		:	updating Manager details to database calls Controller method UpdateManagerInfo(Manager info)

	 ********************************************************************************************************/
	
	
	
	//------------------------ 1. StockExchangeManagement Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	deleteManagerInfo(Manager info) 
	 - Input Parameters	:	Manager info
	 - Return Type		:	manager
	 - Author			:	JennyThanushaw
	 - Creation Date	:	10/11/2020
	 - Description		:	deleting Manager details to database calls Controller method deleteManagerInfo(Integer managerId)

	 ********************************************************************************************************/

	public Manager deleteManagerInfo(int managerId);
}
